function run_localization_starter(inputRoot, outputRoot)
% 当前定位入口仍按采样时刻重排量测，并把延迟量测直接施加到当前状态。
% 交接时需要保留函数入口，重新实现事件裁决、历史回放和协方差更新。
controls = readtable(fullfile(inputRoot,"controls.csv"));
measurements = readtable(fullfile(inputRoot,"measurements.csv"));
measurements = sortrows(measurements,"sample_step"); %#ok<NASGU>
error("Localization:IncompleteFusion","当前入口尚未实现乱序量测回放");
end
